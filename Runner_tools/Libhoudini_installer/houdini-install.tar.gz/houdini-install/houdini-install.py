#!/bin/env python3
import os
work=os.getcwd()
overlay_dir='/var/lib/waydroid/overlay'
print('开始安装Libhoudini(提取自Intel的翻译器)!')
print('请输入你的sudo用户密码')
os.system('sudo echo sudo提权成功!')
os.system(f'cd {overlay_dir} && sudo mkdir -p system/bin')
os.system(f'cd {overlay_dir} && sudo mkdir -p system/etc')
os.system(f'cd {overlay_dir} && sudo mkdir -p system/etc/init')
os.system(f'cd {overlay_dir} && sudo mkdir -p system/lib')
os.system(f'cd {overlay_dir} && sudo mkdir -p system/lib64')
os.system(f'sudo cp -a overlay/system/bin/* {overlay_dir}/system/bin')
os.system(f'sudo cp -a overlay/system/etc/init/* {overlay_dir}/system/etc/init')
os.system(f'sudo cp -a overlay/system/etc/binfmt_misc {overlay_dir}/system/etc')
os.system(f'sudo cp -a overlay/system/lib/* {overlay_dir}/system/lib')
os.system(f'sudo cp -a overlay/system/lib64/* {overlay_dir}/system/lib64')
print('安装完成!')

