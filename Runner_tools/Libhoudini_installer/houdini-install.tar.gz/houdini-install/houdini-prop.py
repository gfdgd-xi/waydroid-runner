#!/bin/env python3
#此应用请以root身份运行!
#Please running by root!
import os
f = open('/var/lib/waydroid/waydroid.cfg','r+')
a=f.read()
if a.find('ro.product.cpu.abilist=x86_64,x86,arm64-v8a,armeabi-v7a,armeabi')!=-1:
    print('警告:您已修改过此prop!程序即将退出!')
    exit(0)
f.close()
f = open('/var/lib/waydroid/waydroid.cfg','a+')
f.write('\nro.product.cpu.abilist=x86_64,x86,arm64-v8a,armeabi-v7a,armeabi\nro.product.cpu.abilist32=x86,armeabi-v7a,armeabi\nro.product.cpu.abilist64=x86_64,arm64-v8a\nro.dalvik.vm.native.bridge=libhoudini.so\nro.enable.native.bridge.exec=1\nro.dalvik.vm.isa.arm=x86\nro.dalvik.vm.isa.arm64=x86_64\nro.vendor.product.cpu.abilist=x86_64,x86,arm64-v8a,armeabi-v7a,armeabi\nro.vendor.product.cpu.abilist32=x86,armeabi-v7a,armeabi\nro.vendor.product.cpu.abilist64=x86_64,arm64-v8a')
f.close()
os.system('waydroid upgrade -o')
