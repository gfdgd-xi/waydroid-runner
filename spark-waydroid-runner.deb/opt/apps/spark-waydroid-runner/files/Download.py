#!/usr/bin/env python3
import sys
import base64
import requests
print("""浣溪沙
一曲新词酒一杯，去年天气旧亭台。夕阳西下几时回？
无可奈何花落去，似曾相识燕归来。小园香径独徘徊。""")
print("")
print("听一支新曲喝一杯美酒，还是去年的天气旧日的亭台，西落的夕阳何时再回来？那花儿落去我也无可奈何，那归来的燕子似曾相识，在小园的花径上独自徘徊。")
print("================================")
print(requests.get(base64.b64decode("aHR0cDovLzEyMC4yNS4xNTMuMTQ0L3dheWRyb2lkLXJ1bm5lci9JbnN0YWxsLnBocD9WZXJzaW9uPQ==").decode("utf-8") + sys.argv[1]).text)